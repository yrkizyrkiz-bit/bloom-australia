# Sanative v680 — Audit Brief (updated 2026-06-25)

See `CHANGES_SUMMARY.md` for full change log.

## Compliance copy — cross-vertical public marketing

Shared constants: `src/lib/legal/marketing-compliance.ts`  
Reusable block: `src/components/legal/PublicComplianceBlock.tsx`

### Vertical pages rewritten for AHPRA/TGA-aligned public copy

- **Hair health** — Removed before/after patient sliders, outcome stats (83%), named testimonials
- **Men's health + ED** — Removed patient testimonials; delivery-forward copy replaced with pharmacy-dispensing language
- **Women's health** — Removed floating Sarah M. testimonial; removed 30,000+ stat
- **Labs** — Removed 50,000+/4.9/94% social-proof bento; treatment-outcome language softened
- **Services / homepage sections** — BentoHero, HowItWorks, CTASection, LabsSection, CategoryGrid, HeroSection, WeightLossSection
- **Hair assessment funnel** — FAQ outcome/guarantee copy aligned with doctor-led refund policy

### Patterns enforced

- Doctor-led assessment → doctor reviews → options only if clinically appropriate
- No medication brand/class names on public pages
- No named patients, kg lost, disease-resolution, or % outcome stats
- No “no questions asked” / “money-back guarantee” / “180-day guarantee”
- Pharmacy: “Where clinically appropriate, items may be dispensed by Australian-registered pharmacies”

## Run tests

```bash
bun run test src/__tests__/smoke.test.ts
bun run test src/__tests__/security*.test.ts
```

Smoke tests now assert all `PUBLIC_VERTICAL_PATHS` against shared banned-term lists (51 tests passing).

## Priority audit areas

Security, cross-vertical public marketing compliance, WM legal/consent, production leaks.
