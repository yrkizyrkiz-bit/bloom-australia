import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { LEGAL_VERSION } from "@/lib/legal/constants";

const ALLOWED_TYPES = new Set(["PRE_QUIZ", "CONTACT_SMS_EMAIL", "PRE_PAYMENT"]);

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const consentType = String(body.consentType || "");
    const sourcePage = String(body.sourcePage || "");
    const consentVersion = String(body.consentVersion || LEGAL_VERSION);
    const email = body.email ? String(body.email) : undefined;
    const userId = body.userId ? String(body.userId) : undefined;

    if (!ALLOWED_TYPES.has(consentType) || !sourcePage) {
      return NextResponse.json({ error: "Invalid consent payload" }, { status: 400 });
    }

    const record = await prisma.consentRecord.create({
      data: {
        consentType,
        consentVersion,
        sourcePage,
        email,
        userId,
        payload: { method: "passive_continue" },
      },
    });

    return NextResponse.json({ id: record.id, acceptedAt: record.acceptedAt });
  } catch (error) {
    console.error("[consent] Failed to record consent:", error);
    return NextResponse.json({ error: "Failed to record consent" }, { status: 500 });
  }
}
