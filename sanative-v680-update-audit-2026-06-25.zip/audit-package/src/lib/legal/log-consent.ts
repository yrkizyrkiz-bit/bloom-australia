import { LEGAL_VERSION } from "@/lib/legal/constants";

export type ConsentType = "PRE_QUIZ" | "CONTACT_SMS_EMAIL" | "PRE_PAYMENT";

export async function logConsentEvent(input: {
  consentType: ConsentType;
  sourcePage: string;
  email?: string;
  userId?: string;
}) {
  try {
    await fetch("/api/consent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...input,
        consentVersion: LEGAL_VERSION,
      }),
    });
  } catch {
    // Non-blocking — consent logging must not break the funnel
  }
}
